package sec04.point.run;

import java.util.Scanner;

import sec04.point.view.PointMenu;

public class Run {

	public static void main(String[] args) {
		PointMenu menu = new PointMenu();
		menu.mainMenu();
	}
	
}
