package sec05;

public class OverrideExample03 {
	public static void main(String[] args) {
		Job j = new Job("�̻���", 25, "IT Programmer");
		
		System.out.println(j.getInfo());
	}
}
