package sec05;

public class CarExam {
	
	public static void main(String[] args) {
		Car car = new Car();
		car.run();
		Bus bus = new Bus();
		bus.run();
	}
	
}
