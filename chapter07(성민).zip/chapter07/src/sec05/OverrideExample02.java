package sec05;

public class OverrideExample02 {

	public static void main(String[] args) {
		
		Reform r = new Reform();
		r.cutWidth();
		r.cutHeight();
		r.getPrice();
		
	}

}
