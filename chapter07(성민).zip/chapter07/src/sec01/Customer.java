package sec01;

public class Customer {
	private int money;
	private int bonusPoint;
	
	Customer() {
		money = 10000;
		bonusPoint = 0;
	}
	
	Customer(int money) {
		this.money = money;
		this.bonusPoint = 0;
	}
	
}
