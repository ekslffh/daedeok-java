package sec01;

public class CellPhoneExample {

	public static void main(String[] args) {
		DmbCellPhone dcp = new DmbCellPhone();
		
		dcp.powerOn();
		System.out.println(dcp.color);
	}

}
