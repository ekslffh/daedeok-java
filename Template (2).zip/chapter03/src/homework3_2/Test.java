package homework3_2;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		
//		Scanner sc = new Scanner(System.in);
//		String a = sc.nextLine();
//		String[] arr = a.split(" ");
//		for (int i = 0; i < arr.length; i++) {
//			System.out.println(arr[i]);
//		}
		
		String k = new String("dfjk");
		System.out.println(k instanceof Object);
		
	}

}
