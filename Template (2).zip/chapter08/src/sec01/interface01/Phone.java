package sec01.interface01;

public interface Phone {
	int number = 0;
	
	public abstract void turnOn();
	public abstract void turnOff();
}
