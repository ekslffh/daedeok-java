package sec01.interface01;

public class Unit {
	int x;
	int y;
	int currentPower;
}
