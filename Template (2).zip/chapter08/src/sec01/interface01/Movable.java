package sec01.interface01;

public interface Movable {
	void move(int x, int y);
}
