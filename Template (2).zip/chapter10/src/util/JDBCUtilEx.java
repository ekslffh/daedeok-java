package util;

public class JDBCUtilEx {

	public static void main(String[] args) {
		JDBCUtil jdbc = JDBCUtil.getInstance();
	}

}
