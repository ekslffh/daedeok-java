package sec01;

public class Triangle extends Shape {
	

}
