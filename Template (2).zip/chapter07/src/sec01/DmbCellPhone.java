package sec01;

public class DmbCellPhone extends CellPhone {
	public DmbCellPhone() {
	}
}
