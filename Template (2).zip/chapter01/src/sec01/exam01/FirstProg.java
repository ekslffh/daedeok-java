package sec01.exam01;

public class FirstProg {

	public static void main(String[] args) {
		System.out.println("Hello! JavaWorld");
	}

}
