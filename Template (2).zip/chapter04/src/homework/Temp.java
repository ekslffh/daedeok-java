package homework;

public class Temp {

	public static void main(String[] args) {

		byte a = -10;
		System.out.println(~a);
		int i = 0, j = 1;
		System.out.println(i + " " + j);
	}

}
