package sec01.exam01;

public class temp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(((10/10.0)-1.0));
	}

}
