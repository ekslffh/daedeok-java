package controller;

public class MainController {

	public static void main(String[] args) {

		MemberController controller = new MemberController();
		controller.selectList();
		
	}

}
