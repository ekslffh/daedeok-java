
public class ChArr {
	public static void main(String[] args) {
		char[] c = null;
		System.out.println("c: " + c);
		System.out.println(("c: " + c).length());
		System.out.println(("c: " + c).charAt(3));
	}
}
