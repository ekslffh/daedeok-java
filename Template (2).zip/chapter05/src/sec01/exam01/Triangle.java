package sec01.exam01;

public class Triangle {
	int width;
	int height;

	public Triangle() {}

	public Triangle(int width, int height) {
		this.width = width;
		this.height = height;
	}
	
	@Override
	public String toString() {
		return "�ﰢ�� ��ü�Դϴ�.";
	}
	
}
