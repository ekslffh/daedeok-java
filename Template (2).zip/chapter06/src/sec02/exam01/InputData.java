package sec02.exam01;

public class InputData {
	Customer[] customer = {
			new Customer("a001", "1234"),
			new Customer("b001", "0987"),
			new Customer("n001", "5678"),
			new Customer("m001", "9012"),
			new Customer("e001", "3456")
	};
}
