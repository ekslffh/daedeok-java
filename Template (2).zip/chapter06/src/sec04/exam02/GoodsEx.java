package sec04.exam02;

public class GoodsEx {

	public static void main(String[] args) {

		Goods g1 = new Goods("����");
		System.out.println(g1);
		
		Goods g2 = new Goods("����");
		System.out.println(g2);
		
		Goods g3 = new Goods("���찳");
		System.out.println(g3);
		
	}

}
