package sec01.exam01;

public class TvExam {

	public static void main(String[] args) {
		
		Tv t1 = new Tv("LG", 2021, 81.5);
		System.out.println(t1);
		System.out.println("----------------");
		
		Tv t2 = new Tv("SAMSUNG", 2022, 60);
		System.out.println(t2);
		System.out.println("----------------");
		
	}

}
