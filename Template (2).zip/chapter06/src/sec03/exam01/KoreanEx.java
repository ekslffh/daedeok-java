package sec03.exam01;

public class KoreanEx {

	public static void main(String[] args) {

		Korean k1 = new Korean("������");

		System.out.println(k1.nation);
		System.out.println(k1.name);
		System.out.println(k1.ssn);
				
	}

}
