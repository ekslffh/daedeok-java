package sec03.exam01;

public class IOEx {

	public static void main(String[] args) {

//		Stack stack = new Stack();
//		for (int i = 0; i < 11; i++) {
//			stack.push((i + 1) + "��° �Է�");
//		}
//		for (int i = 0; i < 10; i++) {
//			System.out.println(stack.pop());
//		}
//		if (stack.isEmpty()) {
//			System.out.println("stack is empty");
//		} else {
//			System.out.println("stack is not empty");
//		}
		
//		Queue queue = new Queue();
//		for (int i = 0; i < 11; i++) {
//			queue.push((i + 1) + "���� �Է�");
//		}
//		for (int i = 0; i < 10; i++) {
//			System.out.println(queue.pop());
//		}
//		if (queue.isEmpty()) {
//			System.out.println("queue is empty");
//		} else {
//			System.out.println("queue is not empty");
//		}
		
	}

}
