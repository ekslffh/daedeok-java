package sec05.exam01;

public class DBConnMain {

	public static void main(String[] args) {
		DBConnService dbConnService = new DBConnService();
		dbConnService.selectAll();
	}

}
