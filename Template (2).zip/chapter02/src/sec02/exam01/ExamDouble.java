package sec02.exam01;

public class ExamDouble {

	public static void main(String[] args) {
		int b = 100;
		long num = 1000;
		char c = 'A';
		
		float fnum = 10;
		
		float res = b + num + fnum;
		
		int result = c + 15;
		 
		System.out.println((char)result);
	}

}
