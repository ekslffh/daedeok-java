package sec02.exam01;

public class ExamInteger01 {

	public static void main(String[] args) {

		byte b1 = 100;
		short sh = 32767;
		int i1 = 100;
		long l1 = 100L;
		
		byte b2 = (byte)(b1 + 28); // => -128
		System.out.println(b2);
		
	}

}
