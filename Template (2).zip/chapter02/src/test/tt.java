package test;

public class tt {
	public static void main(String[] args) {
		double result = Math.pow(3, 3);
		System.out.println(result);
	}
}
